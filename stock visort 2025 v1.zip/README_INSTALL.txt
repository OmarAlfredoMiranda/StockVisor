Stock Visort 2025 v1 – Instalación rápida (Windows)
===================================================

Requisitos
- Windows 10 o superior
- Python 3.10/3.11 instalado y en el PATH
- Conexión a Internet para descargar dependencias (PyTorch y OpenCV)

Pasos
1) Extrae el ZIP en una carpeta sin espacios raros (p. ej. C:\StockVisor)
2) Abre la carpeta y ejecuta: install.bat
   - Crea .venv e instala dependencias (PyTorch CPU, Flask, Ultralytics, etc.)
3) Para iniciar la app: run_web.bat
   - Abre el servidor en http://127.0.0.1:5000
   - Navega a “LiveCam” desde la barra superior

Notas
- El modelo yolov8n.pt se descarga automáticamente durante la instalación.
  Si querés otro modelo, reemplazá el archivo en la raíz y ajustá en web/app.py si hace falta.
- Si tenés GPU NVIDIA y querés PyTorch CUDA, instalalo por tu cuenta con:
  .venv\Scripts\pip install --index-url https://download.pytorch.org/whl/cu121 torch torchvision torchaudio
  (luego vuelve a ejecutar: .venv\Scripts\pip install -r requirements-min.txt)
- Si ‘install.bat’ falla, abrí una consola, activá .venv y ejecutá pip manualmente para ver el error completo.

Estructura del ZIP
- web/                (aplicación Flask)
- yolov8n.pt          (modelo)
- install.bat         (instalador)
- run_web.bat         (ejecutor)
- requirements-min.txt
- README_INSTALL.txt
