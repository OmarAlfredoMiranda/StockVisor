﻿
import os, time, threading, unicodedata, sqlite3, contextlib, datetime as dt, csv
from flask import Flask, request, jsonify, render_template, send_from_directory, Response
from flask_cors import CORS
from PIL import Image
import numpy as np

try: import torch
except Exception: torch = None
try: import cv2
except Exception: cv2 = None
try:
    from ultralytics import YOLO
except Exception:
    YOLO = None

ROOT = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(ROOT)
DATA_DIR = os.path.join(os.path.dirname(ROOT), "data")
UPLOAD_DIR = os.path.join(DATA_DIR, "uploads")
SNAPSHOTS_DIR = os.path.join(DATA_DIR, "snapshots")
DB_PATH = os.path.join(DATA_DIR, "stockvisor.db")
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(SNAPSHOTS_DIR, exist_ok=True)

app = Flask(__name__, static_folder="static", template_folder="templates")
CORS(app)

DEFAULT_CONF, DEFAULT_IMGSZ, DEFAULT_MODEL = 0.25, 640, "yolov8n.pt"
DEVICE = "cuda:0" if (torch and hasattr(torch, "cuda") and torch.cuda.is_available()) else "cpu"

# ---------- Metrics (SQLite) ----------
def _conn():
    return sqlite3.connect(DB_PATH, timeout=10, isolation_level=None)
def init_db():
    with contextlib.closing(_conn()) as c:
        cur=c.cursor()
        cur.execute("""CREATE TABLE IF NOT EXISTS detections(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts INTEGER NOT NULL,
            date TEXT NOT NULL,
            camera_id INTEGER NOT NULL,
            fps REAL NOT NULL,
            class TEXT NOT NULL,
            count INTEGER NOT NULL
        )""")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_det_date_cam ON detections(date,camera_id)")
        cur.execute("""CREATE TABLE IF NOT EXISTS snapshots(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts INTEGER NOT NULL,
            date TEXT NOT NULL,
            camera_id INTEGER NOT NULL,
            filename TEXT NOT NULL,
            filepath TEXT NOT NULL
        )""")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_snap_date_cam ON snapshots(date,camera_id)")
        cur.execute("""CREATE TABLE IF NOT EXISTS alerts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts INTEGER NOT NULL,
            date TEXT NOT NULL,
            camera_id INTEGER NOT NULL,
            type TEXT NOT NULL,
            message TEXT NOT NULL,
            severity TEXT NOT NULL
        )""")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_alert_date_cam ON alerts(date,camera_id)")
        # Leads/Contactos (landing)
        cur.execute("""CREATE TABLE IF NOT EXISTS leads(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts INTEGER NOT NULL,
            name TEXT,
            email TEXT,
            phone TEXT,
            message TEXT
        )""")
        # AOIs por cÃ¡mara
        cur.execute("""CREATE TABLE IF NOT EXISTS aoi(
            camera_id INTEGER PRIMARY KEY,
            rects TEXT NOT NULL
        )""")
        cur.execute("""CREATE TABLE IF NOT EXISTS live_settings(
            camera_id INTEGER PRIMARY KEY,
            settings TEXT NOT NULL
        )""")
        cur.execute("""CREATE TABLE IF NOT EXISTS live_presets(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            camera_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            settings TEXT NOT NULL,
            UNIQUE(camera_id, name)
        )""")
init_db()

def clean_snapshots():
    snapshots = sorted([f for f in os.listdir(SNAPSHOTS_DIR) if f.endswith('.jpg')], key=lambda x: os.path.getmtime(os.path.join(SNAPSHOTS_DIR, x)))
    if len(snapshots) > 10:
        for old in snapshots[:-10]:
            os.remove(os.path.join(SNAPSHOTS_DIR, old))

def log_counts(camera_id:int, fps:float, per_class:dict):
    now = dt.datetime.utcnow()
    ts_ms = int(now.timestamp()*1000)
    day = now.strftime("%Y-%m-%d")
    rows = [(ts_ms, day, camera_id, float(fps or 0.0), str(k), int(v)) for k,v in per_class.items()]
    if not rows:
        rows = [(ts_ms, day, camera_id, float(fps or 0.0), "_heartbeat", 1)]
    with contextlib.closing(_conn()) as c:
        cur = c.cursor()
        cur.executemany("INSERT INTO detections(ts,date,camera_id,fps,class,count) VALUES(?,?,?,?,?,?)", rows)

def agg_day(camera_id:int, date_str:str):
    q = """SELECT class, SUM(count) FROM detections
           WHERE camera_id=? AND date=? GROUP BY class ORDER BY class"""
    with contextlib.closing(_conn()) as c:
        cur=c.cursor(); cur.execute(q, (camera_id, date_str))
        return [{"class":r[0], "count": int(r[1] or 0)} for r in cur.fetchall()]

def series(camera_id:int, cls:str, hours:int):
    since = int((dt.datetime.utcnow() - dt.timedelta(hours=hours)).timestamp()*1000)
    q = """SELECT ts, SUM(count) FROM detections
           WHERE camera_id=? AND class=? AND ts>=?
           GROUP BY ts ORDER BY ts"""
    with contextlib.closing(_conn()) as c:
        cur=c.cursor(); cur.execute(q, (camera_id, cls, since))
        return [{"ts": int(ts), "count": int(n)} for ts,n in cur.fetchall()]

def export_day_csv(camera_id:int, date_str:str, out_path:str):
    rows = agg_day(camera_id, date_str)
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["class","count"])
        for r in rows: w.writerow([r["class"], r["count"]])
    return out_path

def get_snapshots(camera_id:int, limit:int=50):
    q = """SELECT id, ts, date, filename FROM snapshots
           WHERE camera_id=? ORDER BY ts DESC LIMIT ?"""
    with contextlib.closing(_conn()) as c:
        cur=c.cursor(); cur.execute(q, (camera_id, limit))
        return [{"id":r[0], "ts":r[1], "date":r[2], "filename":r[3]} for r in cur.fetchall()]

def log_alert(camera_id:int, alert_type:str, message:str, severity:str="info"):
    now = dt.datetime.utcnow()
    ts_ms = int(now.timestamp()*1000)
    day = now.strftime("%Y-%m-%d")
    with contextlib.closing(_conn()) as c:
        cur = c.cursor()
        cur.execute("INSERT INTO alerts(ts,date,camera_id,type,message,severity) VALUES(?,?,?,?,?,?)",
                    (ts_ms, day, camera_id, alert_type, message, severity))

# ---------- YOLO + Live engine ----------
def _norm(s: str) -> str:
    if not s: return ""
    s = unicodedata.normalize("NFKD", s.strip().lower()).encode("ascii","ignore").decode("ascii")
    return s
def alias_name(name: str) -> str:
    n = _norm(name)
    if n in ("person","persona"): return "persona"
    if n in ("bottle","cup","wine glass","vaso","producto","productos"): return "producto"
    if n in ("refrigerator","fridge","heladera"): return "refrigerador"
    if n in ("cell phone","mobile phone","telefono","telefono movil","celular","phone"): return "celular"
    if n in ("tv","tvmonitor","monitor","pantalla"): return "televisor"
    if n in ("tie","corbata"): return "corbata"
    if n in ("laptop","notebook","computadora portatil","computer","ordenador"): return "notebook"
    if n in ("keyboard","teclado"): return "teclado"
    if n in ("mouse",): return "mouse"
    if n in ("remote","control remoto","control"): return "control"
    if n in ("book","libro"): return "libro"
    if n in ("backpack","mochila"): return "mochila"
    if n in ("handbag","bolso","cartera"): return "cartera"
    if n in ("suitcase","valija","maleta"): return "valija"
    if n in ("umbrella","paraguas"): return "paraguas"
    if n in ("sports ball","pelota","balon"): return "pelota"
    if n in ("bench","banco"): return "banco"
    if n in ("chair","silla"): return "silla"
    if n in ("couch","sofa","sofa"): return "sofa"
    if n in ("potted plant","planta"): return "planta"
    if n in ("vase","florero"): return "florero"
    if n in ("bed","cama"): return "cama"
    if n in ("dining table","mesa"): return "mesa"
    if n in ("microwave","microondas"): return "microondas"
    if n in ("oven","horno"): return "horno"
    if n in ("toaster","tostadora"): return "tostadora"
    if n in ("sink","fregadero","bacha"): return "bacha"
    if n in ("clock","reloj"): return "reloj"
    if n in ("scissors","tijera","tijeras"): return "tijera"
    if n in ("teddy bear","oso de peluche"): return "oso de peluche"
    if n in ("hair drier","secador","secador de pelo"): return "secador"
    if n in ("toothbrush","cepillo de dientes"): return "cepillo de dientes"
    if n == "zona": return "zona"
    if n in ("frente vacio","frente-vacio","frente_vacio"): return "frente vacio"
    return name

class ModelManager:
    def __init__(self):
        self.path = DEFAULT_MODEL
        self.model = None
    def load(self, path=None):
        if path: self.path = path
        m = YOLO(self.path)
        try:
            if DEVICE.startswith("cuda"): m.to(DEVICE)
        except Exception: pass
        # warmup
        m.predict(source=np.zeros((DEFAULT_IMGSZ,DEFAULT_IMGSZ,3),dtype=np.uint8),
                  device=("cuda:0" if DEVICE.startswith("cuda") else "cpu"),
                  imgsz=DEFAULT_IMGSZ, conf=DEFAULT_CONF, verbose=False)
        self.model = m
        print(f"[Model] loaded {self.path} -> {('cuda' if DEVICE.startswith('cuda') else 'cpu')}")
        return m
    def get(self):
        return self.model or self.load(self.path)
model_mgr = ModelManager()
def get_model(): return model_mgr.get()

class LiveEngine:
    def __init__(self):
        self.lock = threading.Lock()
        self.running=False; self.th=None; self.cap=None
        self.last_frame=None; self.last_boxes=[]; self.last_ts=0; self.fps=0.0
        # intervalo para almacenar mÃ©tricas en DB (segundos)
        self.store_interval = 1.0
        self._last_store = 0.0
        self._accum = {}
        # opciones runtime
        self.overlay_boxes = True
        self.overlay_zones = True
        self.overlay_labels = True
        self.filter_classes = set()
        self.aoi = []  # rects normalizados {x,y,w,h}
    def start(self, cam=0, conf=DEFAULT_CONF, imgsz=DEFAULT_IMGSZ):
        if self.running: return
        if cv2 is None: raise RuntimeError("OpenCV no disponible. EjecutÃ¡ START_StockVisor.bat")
        self.cam=int(cam); self.conf=float(conf); self.imgsz=int(imgsz)
        self.cap=cv2.VideoCapture(self.cam, cv2.CAP_DSHOW if hasattr(cv2,'CAP_DSHOW') else 0)
        try:
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH,1280); self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT,720)
        except Exception: pass
        _=get_model()
        # Cargar AOIs persistidas para esta cÃ¡mara
        try:
            with contextlib.closing(_conn()) as c:
                cur=c.cursor(); cur.execute("SELECT rects FROM aoi WHERE camera_id=?", (self.cam,))
                row=cur.fetchone()
                if row and row[0]:
                    import json
                    self.aoi = json.loads(row[0]) or []
        except Exception:
            self.aoi = []
        self.running=True; self.th=threading.Thread(target=self._loop, daemon=True); self.th.start()
    def stop(self):
        self.running=False
        if self.th: self.th.join(timeout=1.0); self.th=None
        if self.cap is not None:
            try: self.cap.release()
            except Exception: pass
            self.cap=None
    def _loop(self):
        m=get_model()
        names = m.model.names if hasattr(m,"model") else m.names
        t0=time.time(); n=0
        while self.running:
            ok, frame = self.cap.read() if self.cap else (False, None)
            if not ok: time.sleep(0.02); continue
            try:
                r = m.predict(source=frame, conf=self.conf, imgsz=self.imgsz,
                              device=("cuda:0" if DEVICE.startswith("cuda") else "cpu"),
                              half=DEVICE.startswith("cuda"), verbose=False)[0]
            except Exception as e:
                print("[YOLO]", e); time.sleep(0.02); continue
            boxes=[]
            for b in r.boxes:
                x1,y1,x2,y2 = b.xyxy[0].tolist()
                cid = int(b.cls[0].item()) if hasattr(b.cls[0],"item") else int(b.cls[0])
                cname_raw = str(names.get(cid,cid)); conf=float(b.conf[0])
                cname = alias_name(cname_raw)
                boxes.append({"x":x1,"y":y1,"w":x2-x1,"h":y2-y1,"cls":cname,"conf":conf})
            with self.lock:
                self.last_frame = frame
                self.last_boxes = boxes
                self.last_ts = int(time.time()*1000)
            n+=1
            if n>=10:
                dt=time.time()-t0
                if dt>0: self.fps=n/dt
                t0=time.time(); n=0
            # --- acumulaciÃ³n y grabado segÃºn intervalo configurado ---
            per = {}
            for b in boxes: per[b["cls"]] = per.get(b["cls"],0)+1
            # acumular
            for k,v in per.items():
                self._accum[k] = self._accum.get(k, 0) + int(v)
            # grabar cuando pasa el intervalo
            if time.time() - self._last_store >= float(self.store_interval or 1.0):
                try:
                    log_counts(camera_id=self.cam, fps=self.fps, per_class=(self._accum or {}))
                except Exception as e:
                    print("[metrics]", e)
                self._accum = {}
                self._last_store = time.time()
            time.sleep(0.001)
    def set_store_interval(self, seconds: float):
        # Limitar entre 0.5s y 86400s (1 dÃ­a)
        try:
            s = max(0.5, min(float(seconds), 86400.0))
        except Exception:
            s = 1.0
        self.store_interval = s
        # Reiniciar acumulador para comenzar nueva ventana
        self._accum = {}
        self._last_store = time.time()
    def _box_in_aois(self, b: dict, W: int, H: int) -> bool:
        """Devuelve True si la caja b (en pixeles) intersecta al menos un AOI.
        b: {'x','y','w','h'} en coordenadas de imagen
        AOIs: lista de rects normalizados {'x','y','w','h'} en [0,1]
        """
        try:
            if not self.aoi:
                return True
            bx1, by1 = float(b.get('x', 0)), float(b.get('y', 0))
            bx2, by2 = bx1 + float(b.get('w', 0)), by1 + float(b.get('h', 0))
            if bx2 <= bx1 or by2 <= by1:
                return False
            for r in self.aoi:
                rx1, ry1 = float(r.get('x', 0)) * W, float(r.get('y', 0)) * H
                rw, rh = float(r.get('w', 0)) * W, float(r.get('h', 0)) * H
                if rw <= 0 or rh <= 0:
                    continue
                rx2, ry2 = rx1 + rw, ry1 + rh
                ix1, iy1 = max(bx1, rx1), max(by1, ry1)
                ix2, iy2 = min(bx2, rx2), min(by2, ry2)
                if ix2 > ix1 and iy2 > iy1:
                    return True
            return False
        except Exception:
            # En caso de datos malformados, permitir pasar la caja para no romper flujo
            return True
    def apply_config(self, cfg: dict):
        if not isinstance(cfg, dict):
            return
        if 'conf' in cfg:
            try: self.conf = float(cfg.get('conf'))
            except Exception: pass
        if 'imgsz' in cfg:
            try: self.imgsz = int(cfg.get('imgsz'))
            except Exception: pass
        if 'overlay_boxes' in cfg: self.overlay_boxes = bool(cfg.get('overlay_boxes'))
        if 'overlay_zones' in cfg: self.overlay_zones = bool(cfg.get('overlay_zones'))
        if 'overlay_labels' in cfg: self.overlay_labels = bool(cfg.get('overlay_labels'))
        if 'filter_classes' in cfg:
            try:
                vals = cfg.get('filter_classes') or []
                self.filter_classes = set([str(v) for v in vals])
            except Exception:
                self.filter_classes = set()
        if 'aoi' in cfg:
            try:
                a = cfg.get('aoi') or []
                norm=[]
                for r in a:
                    x=float(r.get('x',0)); y=float(r.get('y',0)); w=float(r.get('w',0)); h=float(r.get('h',0))
                    if w>0 and h>0:
                        norm.append({'x':max(0,min(1,x)), 'y':max(0,min(1,y)), 'w':max(0,min(1,w)), 'h':max(0,min(1,h))})
                self.aoi = norm
            except Exception:
                pass
    def stats(self):
        with self.lock:
            if self.last_frame is None:
                return {"ts": int(time.time()*1000), "fps": 0.0, "total": 0, "per_class": {}, "per_aoi": []}
            H,W = self.last_frame.shape[:2]
            per = {}
            per_aoi = []
            for r in (self.aoi or []):
                # incluye nombre/color si están definidos
                per_aoi.append({
                    "name": str(r.get('name','')) if isinstance(r, dict) else "",
                    "color": str(r.get('color','')) if isinstance(r, dict) else "",
                    "total": 0,
                    "per_class": {}
                })
            for b in self.last_boxes:
                # filtrar por clases si se configuró
                if self.filter_classes and b.get("cls") not in self.filter_classes:
                    continue
                per[b["cls"]] = per.get(b["cls"],0)+1
                if self.aoi:
                    bx1,by1,bx2,by2 = b['x'], b['y'], b['x']+b['w'], b['y']+b['h']
                    for i,r in enumerate(self.aoi):
                        rx1,ry1 = r['x']*W, r['y']*H
                        rx2,ry2 = rx1 + r['w']*W, ry1 + r['h']*H
                        ix1,iy1 = max(bx1,rx1), max(by1,ry1)
                        ix2,iy2 = min(bx2,rx2), min(by2,ry2)
                        if ix2>ix1 and iy2>iy1:
                            pa = per_aoi[i]
                            pa['total'] = int(pa.get('total',0)) + 1
                            pa['per_class'][b['cls']] = pa['per_class'].get(b['cls'],0)+1
            return {"ts": self.last_ts, "fps": self.fps, "total": sum(per.values()), "per_class": per, "per_aoi": per_aoi}
    def annotated_frame(self):
        with self.lock:
            if self.last_frame is None: return None
            frame = self.last_frame.copy()
            boxes = list(self.last_boxes)
        try:
            import cv2 as _cv2
            for b in boxes:
                # respeta filtro de clases
                if self.filter_classes and b.get("cls") not in self.filter_classes:
                    continue
                x,y,w,h = map(int,(b["x"],b["y"],b["w"],b["h"]))
                if self.overlay_boxes:
                    col = (75,107,255) if b["cls"]=="persona" else (109,253,109) if b["cls"] in ("producto","zona") else (255,211,90)
                    _cv2.rectangle(frame,(x,y),(x+w,y+h), col,2)
                if self.overlay_labels:
                    _cv2.putText(frame, f'{b["cls"]} {b["conf"]:.2f}', (x,y-6), _cv2.FONT_HERSHEY_SIMPLEX, 0.5,(230,240,255),1,_cv2.LINE_AA)
            ok, jpg = _cv2.imencode(".jpg", frame)
            if not ok: return None
            return jpg.tobytes()
        except Exception:
            return None
    def mjpeg(self):
        boundary=b"--frame"
        while self.running:
            chunk = self.annotated_frame()
            if chunk is None: time.sleep(0.03); continue
            yield boundary + b"\r\nContent-Type: image/jpeg\r\nContent-Length: " + str(len(chunk)).encode() + b"\r\n\r\n" + chunk + b"\r\n"

live = LiveEngine()

# ---------- Pages ----------
@app.get("/")
def home(): return render_template("inicio.html")
@app.get("/landing")
def landing_page():
    # PÃ¡gina principal pÃºblica (marketing)
    return render_template("Paginaprincipal.html")
@app.get("/dashboard")
def dashboard(): return render_template("dashboard.html")
@app.get("/alerts")
def alerts(): return render_template("alerts.html")
@app.get("/products")
def products(): return render_template("products.html")
@app.get("/reports")
def reports(): return render_template("reports.html")
@app.get("/cameras")
def cameras(): return render_template("cameras.html")
@app.get("/live")
def live_page(): return render_template("live.html")
@app.get("/mosaic")
def mosaic_page():
    return render_template("mosaic.html")
@app.route("/single", methods=["GET","POST"])
def single():
    if (request.method == "GET"):
        return render_template("single.html", out_url=None, total=0, per={})
    f = request.files.get("file")
    if not f: return render_template("single.html", out_url=None, total=0, per={})
    p=os.path.join(UPLOAD_DIR, f"up_{int(time.time())}.jpg"); f.save(p)
    img = Image.open(p).convert("RGB"); arr = np.array(img)[:,:,::-1]
    m=get_model()
    r = m.predict(source=arr, conf=DEFAULT_CONF, imgsz=DEFAULT_IMGSZ,
                  device=("cuda:0" if DEVICE.startswith("cuda") else "cpu"),
                  half=DEVICE.startswith("cuda"), verbose=False)[0]
    names = m.model.names if hasattr(m,"model") else m.names
    per={}; boxes=[]
    if hasattr(r, "boxes"):
        for b in r.boxes:
            x1,y1,x2,y2 = b.xyxy[0].tolist()
            cid = int(b.cls[0].item()) if hasattr(b.cls[0],"item") else int(b.cls[0])
            cname_raw = str(names.get(cid,cid)); cname = alias_name(cname_raw); confb=float(b.conf[0])
            boxes.append((x1,y1,x2,y2,cname,confb)); per[cname]=per.get(cname,0)+1
    if cv2 is not None:
        fr = arr.copy()
        for (x1,y1,x2,y2,cname,confb) in boxes:
            x1,y1,x2,y2 = map(int,(x1,y1,x2,y2))
            col = (75,107,255) if cname=="persona" else (109,253,109) if cname in ("producto","zona") else (255,211,90)
            cv2.rectangle(fr,(x1,y1),(x2,y2), col,2)
            txt=f"{cname} {confb:.2f}"; cv2.putText(fr, txt, (x1,y1-6), cv2.FONT_HERSHEY_SIMPLEX, 0.5,(230,240,255),1,cv2.LINE_AA)
        out=f"out_{int(time.time())}.jpg"; cv2.imwrite(os.path.join(UPLOAD_DIR,out), fr)
        return render_template("single.html", out_url=f"/uploads/{out}", total=sum(per.values()), per=per)
    return render_template("single.html", out_url=None, total=sum(per.values()), per=per)

# ---------- Live endpoints ----------
@app.post("/live/start")
def live_start():
    d=request.get_json(silent=True) or {}
    try:
        live.set_store_interval(float(d.get("store_interval_sec", live.store_interval)))
        live.start(cam=d.get("cam",0), conf=d.get("conf", DEFAULT_CONF), imgsz=d.get("imgsz", DEFAULT_IMGSZ))
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(error=str(e)), 500
@app.post("/live/stop")
def live_stop():
    try: live.stop(); return jsonify(ok=True)
    except Exception as e: return jsonify(error=str(e)), 500
@app.get("/live/stream")
def live_stream():
    resp = Response(live.mjpeg(), mimetype="multipart/x-mixed-replace; boundary=frame")
    resp.headers["Cache-Control"]="no-store"
    return resp
@app.get("/live/stats")
def live_stats():
    resp = jsonify(live.stats())
    resp.headers["Cache-Control"]="no-store"
    return resp

@app.post("/live/config")
def live_config():
    d = request.get_json(silent=True) or {}
    if "store_interval_sec" in d:
        try:
            live.set_store_interval(float(d.get("store_interval_sec")))
        except Exception as e:
            return jsonify(ok=False, error=str(e)), 400
    # aplicar otros parÃ¡metros (conf, imgsz, overlays, filtros, aoi)
    try:
        live.apply_config(d)
        # persistir AOIs si vienen
        if 'aoi' in d:
            import json
            with contextlib.closing(_conn()) as c:
                cur=c.cursor()
                cur.execute("INSERT INTO aoi(camera_id,rects) VALUES(?,?) ON CONFLICT(camera_id) DO UPDATE SET rects=excluded.rects", (getattr(live,'cam',0), json.dumps(d.get('aoi') or [])))
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400
    return jsonify(ok=True, store_interval_sec=live.store_interval)

@app.post("/live/snapshot")
def live_snapshot():
    chunk = live.annotated_frame()
    if not chunk:
        return jsonify({"error": "no_frame"}), 404
    ts = int(time.time())
    date_str = dt.datetime.fromtimestamp(ts).strftime("%Y-%m-%d")
    filename = f"snapshot_{ts}.jpg"
    filepath = os.path.join(SNAPSHOTS_DIR, filename)
    with open(filepath, "wb") as f:
        f.write(chunk)
    clean_snapshots()
    # Insert into DB
    with contextlib.closing(_conn()) as c:
        cur = c.cursor()
        cur.execute("INSERT INTO snapshots(ts,date,camera_id,filename,filepath) VALUES(?,?,?,?,?)",
                    (ts, date_str, 0, filename, filepath))
    return jsonify({"filename": filename})

# ---------- Metrics endpoints ----------
@app.get("/v1/agg/day")
def v1_agg_day():
    date_str = request.args.get("date") or dt.date.today().strftime("%Y-%m-%d")
    camera_id = int((request.args.get("camera_id") or 0))
    return jsonify({"date": date_str, "camera_id": camera_id, "rows": agg_day(camera_id, date_str)})

@app.get("/v1/series")
def v1_series():
    camera_id = int((request.args.get("camera_id") or 0))
    cls = request.args.get("cls") or "producto"
    hours = int((request.args.get("hours") or 24))
    return jsonify({"camera_id": camera_id, "cls": cls, "hours": hours, "points": series(camera_id, cls, hours)})

@app.get("/v1/export/day")
def v1_export_day():
    date_str = request.args.get("date") or dt.date.today().strftime("%Y-%m-%d")
    camera_id = int((request.args.get("camera_id") or 0))
    out = os.path.join(DATA_DIR, f"agg_{camera_id}_{date_str}.csv")
    export_day_csv(camera_id, date_str, out)
    return send_from_directory(DATA_DIR, os.path.basename(out), as_attachment=True)

@app.get("/v1/snapshots")
def v1_snapshots():
    camera_id = int((request.args.get("camera_id") or 0))
    limit = int((request.args.get("limit") or 50))
    return jsonify({"camera_id": camera_id, "limit": limit, "snapshots": get_snapshots(camera_id, limit)})

@app.get("/v1/alerts")
def v1_alerts():
    camera_id = int((request.args.get("camera_id") or 0))
    date_str = request.args.get("date") or dt.date.today().strftime("%Y-%m-%d")
    q = """SELECT id, ts, type, message, severity FROM alerts
           WHERE camera_id=? AND date=? ORDER BY ts DESC"""
    with contextlib.closing(_conn()) as c:
        cur=c.cursor(); cur.execute(q, (camera_id, date_str))
        return jsonify({"camera_id": camera_id, "date": date_str, "alerts": [{"id":r[0], "ts":r[1], "type":r[2], "message":r[3], "severity":r[4]} for r in cur.fetchall()]})


@app.get("/v1/live/frame.jpg")
def v1_live_frame():
    chunk = live.annotated_frame()
    if not chunk:
        return jsonify({"error":"no_frame"}), 404
    return Response(chunk, mimetype="image/jpeg", headers={"Cache-Control":"no-store"})

@app.get("/v1/live/shot.jpg")
def v1_live_shot():
    """Captura única anotada de una cámara específica (sin cambiar el engine)."""
    cam = int(request.args.get('camera_id') or 0)
    conf = float(request.args.get('conf') or DEFAULT_CONF)
    imgsz = int(request.args.get('imgsz') or DEFAULT_IMGSZ)
    if cv2 is None:
        return jsonify({"error":"opencv_unavailable"}), 500
    m = get_model()
    # intentar con varios backends para Windows (DSHOW/MSMF)
    backends = []
    if hasattr(cv2,'CAP_DSHOW'): backends.append(cv2.CAP_DSHOW)
    if hasattr(cv2,'CAP_MSMF'): backends.append(cv2.CAP_MSMF)
    backends.append(0)  # default
    frame=None; ok=False
    for be in backends:
        try:
            cap = cv2.VideoCapture(cam, be)
            ok, frame = cap.read()
            cap.release()
            if ok: break
        except Exception:
            try:
                cap.release()
            except Exception:
                pass
    try:
        pass
    except Exception:
        pass
    if not ok:
        return jsonify({"error":"no_frame"}), 404
    try:
        r = m.predict(source=frame, conf=conf, imgsz=imgsz,
                      device=("cuda:0" if DEVICE.startswith("cuda") else "cpu"),
                      half=DEVICE.startswith("cuda"), verbose=False)[0]
        names = m.model.names if hasattr(m,'model') else m.names
        boxes=[]
        for b in r.boxes:
            x1,y1,x2,y2 = b.xyxy[0].tolist()
            cid = int(b.cls[0].item()) if hasattr(b.cls[0],"item") else int(b.cls[0])
            cname_raw = str(names.get(cid,cid)); confb=float(b.conf[0])
            cname = alias_name(cname_raw)
            boxes.append((int(x1),int(y1),int(x2),int(y2),cname,confb))
        fr = frame.copy()
        for (x1,y1,x2,y2,cname,confb) in boxes:
            col = (75,107,255) if cname=="persona" else (109,253,109) if cname in ("producto","zona") else (255,211,90)
            cv2.rectangle(fr,(x1,y1),(x2,y2), col,2)
            cv2.putText(fr, f"{cname} {confb:.2f}", (x1,y1-6), cv2.FONT_HERSHEY_SIMPLEX, 0.5,(230,240,255),1,cv2.LINE_AA)
        ok, jpg = cv2.imencode('.jpg', fr)
        if not ok:
            return jsonify({"error":"encode_failed"}), 500
        return Response(jpg.tobytes(), mimetype='image/jpeg', headers={"Cache-Control":"no-store"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.get("/v1/cameras")
def v1_cameras():
    cams=[]
    try:
        if cv2 is not None:
            for i in range(4):
                cap=cv2.VideoCapture(i, cv2.CAP_DSHOW if hasattr(cv2,'CAP_DSHOW') else 0)
                ok=cap.isOpened()
                try: cap.release()
                except Exception: pass
                if ok: cams.append({"id": i, "name": f"Cam {i}"})
    except Exception:
        pass
    if not cams: cams=[{"id":0, "name":"Cam 0"}]
    return jsonify(cams)

@app.get("/v1/classes")
def v1_classes():
    try:
        m = get_model()
        names = m.model.names if hasattr(m,'model') else getattr(m,'names',{})
        arr=[alias_name(str(v)) for _,v in (names.items() if isinstance(names,dict) else enumerate(names))]
        seen=[]
        for x in arr:
            if x not in seen: seen.append(x)
        return jsonify(seen)
    except Exception:
        return jsonify(["producto","persona","zona"]) 

@app.get("/v1/live/settings")
def v1_live_settings_get():
    cam = int(request.args.get('camera_id') or 0)
    with contextlib.closing(_conn()) as c:
        cur=c.cursor(); cur.execute("SELECT settings FROM live_settings WHERE camera_id=?", (cam,))
        row=cur.fetchone()
        import json
        s = {} if not row or not row[0] else json.loads(row[0])
        return jsonify({"camera_id": cam, "settings": s})

@app.post("/v1/live/settings")
def v1_live_settings_set():
    d = request.get_json(silent=True) or {}
    cam = int(d.get('camera_id') or 0)
    s = d.get('settings') or {}
    import json
    with contextlib.closing(_conn()) as c:
        cur=c.cursor(); cur.execute(
            "INSERT INTO live_settings(camera_id,settings) VALUES(?,?) ON CONFLICT(camera_id) DO UPDATE SET settings=excluded.settings",
            (cam, json.dumps(s))
        )
    return jsonify(ok=True)

# --------- Live presets (por cámara) ---------
@app.get("/v1/live/presets")
def v1_live_presets_get():
    cam = int(request.args.get('camera_id') or 0)
    with contextlib.closing(_conn()) as c:
        cur=c.cursor()
        cur.execute("SELECT id,name,settings FROM live_presets WHERE camera_id=? ORDER BY name", (cam,))
        import json
        rows=[{"id":r[0],"name":r[1],"settings": (json.loads(r[2]) if r[2] else {})} for r in cur.fetchall()]
    return jsonify({"camera_id": cam, "presets": rows})

@app.post("/v1/live/presets")
def v1_live_presets_set():
    d = request.get_json(silent=True) or {}
    cam = int(d.get('camera_id') or 0)
    name = (d.get('name') or '').strip()
    settings = d.get('settings') or {}
    if not name:
        return jsonify(ok=False, error='name_required'), 400
    import json
    with contextlib.closing(_conn()) as c:
        cur=c.cursor()
        cur.execute("INSERT INTO live_presets(camera_id,name,settings) VALUES(?,?,?) ON CONFLICT(camera_id,name) DO UPDATE SET settings=excluded.settings",
                    (cam, name, json.dumps(settings)))
    return jsonify(ok=True)

@app.delete("/v1/live/presets")
def v1_live_presets_delete():
    d = request.get_json(silent=True) or {}
    cam = int(d.get('camera_id') or 0)
    name = (d.get('name') or '').strip()
    if not name:
        return jsonify(ok=False, error='name_required'), 400
    with contextlib.closing(_conn()) as c:
        cur=c.cursor(); cur.execute("DELETE FROM live_presets WHERE camera_id=? AND name=?", (cam, name))
    return jsonify(ok=True)

@app.get("/live/detections")
def live_detections():
    with live.lock:
        if live.last_frame is None:
            return jsonify({"ts": int(time.time()*1000), "fps": 0.0, "boxes": []})
        H,W = live.last_frame.shape[:2]
        out=[]
        for b in live.last_boxes:
            if live.filter_classes and b.get('cls') not in live.filter_classes:
                continue
            if live.aoi and not live._box_in_aois(b, W, H):
                continue
            out.append({"x": b['x']/W, "y": b['y']/H, "w": b['w']/W, "h": b['h']/H, "cls": b['cls'], "conf": b['conf']})
        return jsonify({"ts": live.last_ts, "fps": live.fps, "boxes": out})

@app.get("/v1/aoi")
def v1_get_aoi():
    cam = int(request.args.get('camera_id') or 0)
    with contextlib.closing(_conn()) as c:
        cur=c.cursor(); cur.execute("SELECT rects FROM aoi WHERE camera_id=?", (cam,))
        row=cur.fetchone()
        import json
        return jsonify({"camera_id": cam, "aoi": ([] if not row or not row[0] else json.loads(row[0]))})

@app.post("/v1/aoi")
def v1_save_aoi():
    d=request.get_json(silent=True) or {}
    cam = int(d.get('camera_id') or getattr(live,'cam',0))
    aoi = d.get('aoi') or []
    import json
    with contextlib.closing(_conn()) as c:
        cur=c.cursor(); cur.execute("INSERT INTO aoi(camera_id,rects) VALUES(?,?) ON CONFLICT(camera_id) DO UPDATE SET rects=excluded.rects", (cam, json.dumps(aoi)))
    if getattr(live,'cam',0)==cam:
        try: live.apply_config({'aoi': aoi})
        except Exception: pass

@app.post("/v1/reset/day")
def v1_reset_day():
    date_str = request.args.get("date") or dt.date.today().strftime("%Y-%m-%d")
    camera_id = int((request.args.get("camera_id") or 0))
    with contextlib.closing(_conn()) as c:
        cur=c.cursor()
        cur.execute("DELETE FROM detections WHERE date=? AND camera_id=?", (date_str, camera_id))
    return jsonify({"ok": True, "date": date_str, "camera_id": camera_id})

# ---------- Leads (landing) ----------
@app.post("/v1/leads")
def v1_leads_create():
    data = request.get_json(silent=True) or request.form or {}
    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip()
    phone = (data.get("phone") or "").strip()
    message = (data.get("message") or "").strip()
    ts = int(time.time()*1000)
    with contextlib.closing(_conn()) as c:
        cur=c.cursor()
        cur.execute("INSERT INTO leads(ts,name,email,phone,message) VALUES(?,?,?,?,?)", (ts,name,email,phone,message))
    return jsonify(ok=True)

@app.get("/v1/leads")
def v1_leads_list():
    limit = int(request.args.get("limit") or 200)
    with contextlib.closing(_conn()) as c:
        cur=c.cursor()
        cur.execute("SELECT id,ts,name,email,phone,message FROM leads ORDER BY id DESC LIMIT ?", (limit,))
        rows = [
            {"id":r[0], "ts":r[1], "name":r[2] or "", "email":r[3] or "", "phone":r[4] or "", "message":r[5] or ""}
            for r in cur.fetchall()
        ]
    return jsonify({"rows": rows, "limit": limit})

@app.get("/v1/leads.csv")
def v1_leads_csv():
    import io
    buf = io.StringIO()
    with contextlib.closing(_conn()) as c:
        cur=c.cursor()
        cur.execute("SELECT id,ts,name,email,phone,message FROM leads ORDER BY id DESC")
        w = csv.writer(buf)
        w.writerow(["id","ts","name","email","phone","message"])
        for r in cur.fetchall():
            w.writerow(r)
    out = buf.getvalue().encode("utf-8")
    return Response(out, mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=leads.csv"})

@app.get("/admin/leads")
def admin_leads():
    return render_template("admin_leads.html")
@app.get("/v1/health")
def health():
    try:
        import ultralytics, cv2 as _cv2, torch as _torch
        _ = model_mgr.get()
        dev = None
        try:
            if _torch.cuda.is_available(): dev = _torch.cuda.get_device_name(0)
        except Exception: pass
        return jsonify(ok=True, torch=_torch.__version__, cuda=_torch.cuda.is_available(),
                       device=("cuda:0" if _torch.cuda.is_available() else "cpu"),
                       device_name=dev, ultralytics=ultralytics.__version__, opencv=_cv2.__version__)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500

@app.get("/uploads/<name>")
def uploads(name):
    return send_from_directory(UPLOAD_DIR, name, as_attachment=False)

@app.get("/snapshots/<name>")
def snapshots(name):
    return send_from_directory(SNAPSHOTS_DIR, name, as_attachment=False)

if __name__=="__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)


